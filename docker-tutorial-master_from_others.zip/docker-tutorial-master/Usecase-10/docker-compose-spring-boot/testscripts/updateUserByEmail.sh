 #!/bin/bash
 curl http://192.168.99.100:1111/pictolearn-dispatcher/proxyServlet/findByEmail/arunganesan@xyz\.com -v