#!/bin/bash
# Instructions to install docker
sudo apt-get -y install docker
sudo apt-get -y install docker-engine
sudo apt-get -y install docker-compose
sudo reboot